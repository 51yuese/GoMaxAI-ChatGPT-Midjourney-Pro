const r="/static/png/error-f74c9bd3.png";export{r as _};
