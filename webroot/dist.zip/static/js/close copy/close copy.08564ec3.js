const s="/static/svg/close-9c203e59.svg",c="/static/svg/close copy-6eb5ff7d.svg";export{s as _,c as a};
