const s="/static/svg/file-16b3e23d.svg";export{s as _};
