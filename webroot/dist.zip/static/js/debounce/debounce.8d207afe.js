function e(e,t){let o;return(...r)=>{clearTimeout(o),o=setTimeout((()=>{clearTimeout(o),e(...r)}),t)}}export{e as d};
