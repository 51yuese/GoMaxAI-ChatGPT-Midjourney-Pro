const s="/static/svg/deit-9489834f.svg",a="/static/svg/refresh-62a8a2b2.svg",t="/static/svg/KLingIcon3-f08dc110.svg";export{s as _,a,t as b};
