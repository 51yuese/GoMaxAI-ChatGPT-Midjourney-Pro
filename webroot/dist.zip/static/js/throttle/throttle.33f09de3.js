function t(t,n){let e,u;return function(...i){u=i,e||(e=setTimeout((()=>{t.apply(this,u),e=null}),n))}}export{t};
