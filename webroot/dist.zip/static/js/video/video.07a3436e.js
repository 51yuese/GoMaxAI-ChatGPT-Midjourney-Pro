import{Q as a,cY as t}from"../main-cd5b7247.js";function r(a){return t({url:"/chatgpt/chat-video",data:a})}function n(t){return a({url:"/dict/page",data:t})}export{r as f,n as g};
