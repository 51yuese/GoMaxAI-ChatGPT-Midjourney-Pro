import{Q as a,bH as t}from"../main-6c725c30.js";function r(a){return t({url:"/chatgpt/chat-video",data:a})}function n(t){return a({url:"/dict/page",data:t})}export{r as f,n as g};
