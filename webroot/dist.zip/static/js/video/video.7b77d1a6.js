import{Q as a,bn as t}from"../main-79c61161.js";function r(a,r=""){return t({url:"/chatgpt/chat-video"+(r?"-"+r:""),data:a})}function n(t){return a({url:"/dict/page",data:t})}export{r as f,n as g};
