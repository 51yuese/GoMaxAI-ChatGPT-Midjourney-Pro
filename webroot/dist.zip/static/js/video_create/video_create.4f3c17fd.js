const c="/static/svg/video_create-75cc80e7.svg";export{c as _};
