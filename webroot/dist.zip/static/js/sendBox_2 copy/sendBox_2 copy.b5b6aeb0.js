const s="/static/svg/sendBox_2 copy-a52e6131.svg";export{s as _};
