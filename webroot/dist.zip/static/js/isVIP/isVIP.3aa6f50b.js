const s="/static/svg/isVIP-fe47bc14.svg";export{s as _};
