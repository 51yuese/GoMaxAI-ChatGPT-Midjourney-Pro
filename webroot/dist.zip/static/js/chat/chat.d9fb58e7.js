import{b4 as r}from"../main-4156cf5e.js";function a(){return r({url:"/config/query",data:{keys:["robotAvatar","guideWelcome","chatMarquee"]}})}export{a as v};
