import{aZ as a}from"../main-a0b53047.js";function r(){return a({url:"/config/query",data:{keys:["robotAvatar","guideWelcome","chatMarquee"]}})}export{r as v};
