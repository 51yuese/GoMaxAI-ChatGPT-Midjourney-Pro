import{aZ as r,j as a}from"../main-a0b53047.js";function t(a){return r({url:"/order/buy",data:a})}function u(r){return a({url:"/order/queryByOrderId",data:r})}export{u as a,t as f};
