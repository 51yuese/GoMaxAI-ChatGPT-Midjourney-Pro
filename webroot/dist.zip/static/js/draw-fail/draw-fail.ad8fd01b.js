const s="/static/svg/Discord-e74ecd50.svg",a="/static/png/draw-fail-ce560894.png";export{s as _,a};
