import{aI as a}from"./index-5HZnFt5a.js";const t=a("back",{state:()=>({backData:null}),actions:{setBackData(a){this.backData=a},clearBackData(){this.backData=null}}});export{t as u};
