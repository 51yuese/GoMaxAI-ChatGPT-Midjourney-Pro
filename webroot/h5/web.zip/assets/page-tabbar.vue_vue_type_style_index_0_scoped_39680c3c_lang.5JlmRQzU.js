var o,l,n,a;Boolean,null==(l=null==(o=uni.$uv)?void 0:o.props)||l.tabbarItem,Boolean,Boolean,Boolean,Boolean,null==(a=null==(n=uni.$uv)?void 0:n.props)||a.tabbar;
