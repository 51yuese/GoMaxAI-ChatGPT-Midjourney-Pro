const s="/h5/assets/reserve-DBJDuiDu.png";export{s as _};
