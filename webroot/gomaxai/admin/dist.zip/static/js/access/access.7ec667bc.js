
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{aw as a,ad as e}from"../main-527fe521.js";const s={queryAccessList:e=>a.post("access/query",e),getAccess:a=>{e.warning("接口停用")},deleteAccess:a=>{e.warning("接口停用")},addAccess:a=>{e.warning("接口停用")},updateAccess:a=>{e.warning("接口停用")},updateManagerStatus:a=>{e.warning("接口停用")},resetUserPassword:a=>{e.warning("接口停用")},getSaasPage:e=>a.get("saas/page",{params:e}),deleteSaas:e=>a.post("saas/del",e),saveSaas:e=>a.post("saas/save",e),getRolePage:e=>a.get("role/page",{params:e}),deleteRole:e=>a.post("role/del",e),saveRole:e=>a.post("role/save",e)};export{s as a};
