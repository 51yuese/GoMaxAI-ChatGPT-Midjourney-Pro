
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{ap as a}from"../main-46c178e9.js";const e={queryAllCrami:e=>a.get("crami/queryAllCrami",{params:e,fetchOptions:{saas:!0}}),delCrami:e=>a.post("crami/delCrami",e),createCrami:e=>a.post("crami/createCrami",e),batchDelCrami:e=>a.post("crami/batchDelCrami",e),batchDistribute:e=>a.post("crami/distribute",e),queryAllPackage:e=>a.get("crami/packagePageV2",{params:e,fetchOptions:{saas:!0}}),createPackage:e=>a.post("crami/packageCreateV2",e),updatePackage:e=>a.post("crami/packageUpdateV2",e),delPackage:e=>a.post("crami/packageDeleteV2",e),package4Select:e=>a.get("crami/package4Select",{params:e,fetchOptions:{saas:!0}})};export{e as A};
