
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{d as i,r as e,F as a,o as c,b as s,e as r,f as l,j as o,t,g as p,K as n,c as g,_ as m}from"../main-46c178e9.js";const y={class:"copy-container"},u={style:{color:"#9FA3B8"}},h={key:0},b=["href"],d={key:1},f=["href"],N=i({name:"Copyright"}),F=m(i({...N,setup(i){e({copyrightTitle:"GoMaxAiAdmin",copyrightUrl:"/"});const m=a({agreementTitle:"",policyTitle:"",filingNumber:"",companyName:""});return c((()=>{!async function(){const i=await g.copyright({keys:["copyrightTitle","icpNumber","policeFilingNumber","icpUrl","policeFilingUrl"]});i.success&&Object.assign(m,i.data)}()})),(i,e)=>(s(),r("div",y,[l("div",u,[l("p",null,[o("版权所有 © "+t(p(m).copyrightTitle)+" ",1),p(m).icpNumber?(s(),r("span",h,[l("a",{href:p(m).icpUrl||"#"},t(p(m).icpNumber),9,b)])):n("",!0),p(m).policeFilingNumber?(s(),r("span",d,[l("a",{href:p(m).policeFilingUrl||"#"},t(p(m).policeFilingNumber),9,f)])):n("",!0)])])]))}}),[["__scopeId","data-v-aacddcf8"]]);export{F as _};
