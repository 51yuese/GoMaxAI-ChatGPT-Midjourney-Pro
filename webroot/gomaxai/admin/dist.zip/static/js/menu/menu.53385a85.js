
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{ay as e}from"../main-6fd6ef79.js";const n={quertMenu:n=>e.get("menu/query",{params:n}),visibleMenu:n=>e.post("menu/visible",n),setMenu:n=>e.post("menu/setMenu",n),delMenu:n=>e.post("menu/delete",n),updateIcon:n=>e.post("menu/updateIcon",n)};export{n as a};
