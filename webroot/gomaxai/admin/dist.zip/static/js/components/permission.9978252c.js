
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{_ as s}from"../permission.vue_vue_type_script_setup_true_lang/permission.vue_vue_type_script_setup_true_lang.0fbde22b.js";import"../main-6fd6ef79.js";import"../access/access.e0439180.js";export{s as default};
