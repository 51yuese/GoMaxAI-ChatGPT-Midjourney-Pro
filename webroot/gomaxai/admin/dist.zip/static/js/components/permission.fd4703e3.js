
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{_ as s}from"../permission.vue_vue_type_script_setup_true_lang/permission.vue_vue_type_script_setup_true_lang.d24a79af.js";import"../main-527fe521.js";import"../access/access.7ec667bc.js";export{s as default};
