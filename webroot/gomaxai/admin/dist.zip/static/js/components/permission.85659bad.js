
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{_ as s}from"../permission.vue_vue_type_script_setup_true_lang/permission.vue_vue_type_script_setup_true_lang.91046492.js";import"../main-46c178e9.js";import"../access/access.8e3eb471.js";export{s as default};
