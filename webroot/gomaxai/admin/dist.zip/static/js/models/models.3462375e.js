
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{ay as e}from"../main-6fd6ef79.js";const s={queryModels:s=>e.get("models/query",{params:{...s,isAdmin:1}}),setModels:s=>e.post("models/setModel",s),delModels:s=>e.post("models/delModel",s)};export{s as A};
