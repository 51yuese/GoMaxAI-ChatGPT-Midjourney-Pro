
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{W as s,a7 as t,a5 as e}from"../main-6fd6ef79.js";function n(){const n=s(),a=t();return{switchTo:function(s){a.setActived(s),n.settings.menu.switchMainMenuAndPageJump&&e.push(a.sidebarMenusFirstDeepestPath)}}}export{n as u};
