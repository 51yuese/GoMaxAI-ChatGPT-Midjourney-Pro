
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{a as s,A as t,y as e}from"../main-46c178e9.js";function n(){const n=s(),i=t();return{switchTo:function(s){i.setActived(s),n.settings.menu.switchMainMenuAndPageJump&&e.push(i.sidebarMenusFirstDeepestPath)}}}export{n as u};
