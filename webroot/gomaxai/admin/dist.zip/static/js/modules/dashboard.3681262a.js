
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{ad as t}from"../main-2d3d97e8.js";const a={getBaseInfo:a=>t.get("/statistic/base",{params:a}),getChatStatistic:a=>t.get("/statistic/chatStatistic",{params:a}),getBaiduVisit:a=>t.get("/statistic/baiduVisit",{params:a}),getModelStatisticsChart:a=>t.get("/statistic/modelUse",{params:a})};export{a as default};
