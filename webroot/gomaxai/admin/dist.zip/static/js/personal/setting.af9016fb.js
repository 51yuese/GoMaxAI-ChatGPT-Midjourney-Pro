
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{_ as s}from"../index/index.2a1afca6.js";import{d as a,m as t,r as e,l,b as i,e as n,h as o,i as d,f as c,j as r,_ as u,q as p}from"../main-46c178e9.js";const m={class:"setting-list"},f={class:"item"},v={class:"action"},_=a({name:"PersonalSetting"}),b=a({..._,setup(a){const u=t();function p(){u.push({name:"personalEditPassword"})}return e({headimg:"",mobile:"",name:"",qq:"",wechat:""}),(a,t)=>{const e=l("el-button"),u=l("el-tab-pane"),_=l("el-tabs"),b=s;return i(),n("div",null,[o(b,null,{default:d((()=>[o(_,{"tab-position":"left",style:{height:"600px"}},{default:d((()=>[o(u,{label:"安全设置",class:"security"},{default:d((()=>[t[2]||(t[2]=c("h2",null,"安全设置",-1)),c("div",m,[c("div",f,[t[1]||(t[1]=c("div",{class:"content"},[c("div",{class:"title"}," 账户密码 "),c("div",{class:"desc"}," 当前密码强度：强 ")],-1)),c("div",v,[o(e,{type:"primary",plain:"",onClick:p},{default:d((()=>t[0]||(t[0]=[r(" 修改 ")]))),_:1})])])])])),_:1})])),_:1})])),_:1})])}}});"function"==typeof p&&p(b);const h=u(b,[["__scopeId","data-v-87584ede"]]);export{h as default};
