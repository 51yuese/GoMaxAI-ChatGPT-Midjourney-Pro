
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{_ as s}from"../index/index.684d80e0.js";import{d as a,T as t,r as e,e as l,o as n,f as i,g as o,h as d,m as c,q as r,a1 as u,a2 as p}from"../main-6fd6ef79.js";const m={class:"setting-list"},f={class:"item"},v={class:"action"},h=a({name:"PersonalSetting"}),_=a({...h,setup(a){const u=t();function p(){u.push({name:"personalEditPassword"})}return e({headimg:"",mobile:"",name:"",qq:"",wechat:""}),(a,t)=>{const e=l("el-button"),u=l("el-tab-pane"),h=l("el-tabs"),_=s;return n(),i("div",null,[o(_,null,{default:d((()=>[o(h,{"tab-position":"left",style:{height:"600px"}},{default:d((()=>[o(u,{label:"安全设置",class:"security"},{default:d((()=>[t[2]||(t[2]=c("h2",null,"安全设置",-1)),c("div",m,[c("div",f,[t[1]||(t[1]=c("div",{class:"content"},[c("div",{class:"title"}," 账户密码 "),c("div",{class:"desc"}," 当前密码强度：强 ")],-1)),c("div",v,[o(e,{type:"primary",plain:"",onClick:p},{default:d((()=>t[0]||(t[0]=[r(" 修改 ")]))),_:1})])])])])),_:1})])),_:1})])),_:1})])}}});"function"==typeof p&&p(_);const b=u(_,[["__scopeId","data-v-87584ede"]]);export{b as default};
