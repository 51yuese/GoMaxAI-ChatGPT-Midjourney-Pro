
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{_ as s}from"../index/index.8279f6f1.js";import{d as a,l as t,r as e,j as l,o as n,c as i,f as d,g as o,b as c,h as r,p as u,k as p,_ as f,q as m}from"../main-2d3d97e8.js";const v=s=>(u("data-v-87584ede"),s=s(),p(),s),_=v((()=>c("h2",null,"安全设置",-1))),b={class:"setting-list"},h={class:"item"},g=v((()=>c("div",{class:"content"},[c("div",{class:"title"}," 账户密码 "),c("div",{class:"desc"}," 当前密码强度：强 ")],-1))),y={class:"action"},x=a({name:"PersonalSetting"}),j=a({...x,setup(a){const u=t();function p(){u.push({name:"personalEditPassword"})}return e({headimg:"",mobile:"",name:"",qq:"",wechat:""}),(a,t)=>{const e=l("el-button"),u=l("el-tab-pane"),f=l("el-tabs"),m=s;return n(),i("div",null,[d(m,null,{default:o((()=>[d(f,{"tab-position":"left",style:{height:"600px"}},{default:o((()=>[d(u,{label:"安全设置",class:"security"},{default:o((()=>[_,c("div",b,[c("div",h,[g,c("div",y,[d(e,{type:"primary",plain:"",onClick:p},{default:o((()=>[r(" 修改 ")])),_:1})])])])])),_:1})])),_:1})])),_:1})])}}});"function"==typeof m&&m(j);const q=f(j,[["__scopeId","data-v-87584ede"]]);export{q as default};
