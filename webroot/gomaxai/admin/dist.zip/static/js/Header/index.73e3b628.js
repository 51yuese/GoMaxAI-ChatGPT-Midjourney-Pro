
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{d as e,V as a,a6 as s,r as n,e as t,o as i,j as o,h as l,i as r,f as c,m as d,g as m,$ as u,F as v,J as f,n as p,k as h,t as k,aa as j,a3 as y,a0 as x}from"../main-527fe521.js";import _ from"../Logo/index.1653210c.js";import g from"../Tools/index.db01cd93.js";import{u as M}from"../useMenu/useMenu.f6a36739.js";import"../index/index.7e614874.js";import"../access/access.7ec667bc.js";const C={key:0},T={class:"header-container"},w={class:"main"},B=["onClick"],F={key:1},H=e({name:"Header"}),I=x(e({...H,setup(e){const x=a(),H=s(),{switchTo:I}=M(),J=n();function L(e){J.value.scrollBy({left:(e.deltaY||e.detail)>0?50:-50})}return(e,a)=>{const s=y,n=t("el-icon");return i(),o(j,{name:"header"},{default:l((()=>["pc"===r(x).mode&&"head"===r(x).settings.menu.menuMode?(i(),c("header",C,[d("div",T,[d("div",w,[m(_),d("div",{ref_key:"navRef",ref:J,class:"nav",onWheel:u(L,["prevent"])},[(i(!0),c(v,null,f(r(H).allMenus,((e,a)=>{var t,u;return i(),c(v,{key:a},[e.children&&0!==e.children.length?(i(),c("div",{key:0,class:p(["item-container",{active:a===r(H).actived}])},[d("div",{class:"item",onClick:e=>r(I)(a)},[(null==(t=e.meta)?void 0:t.icon)?(i(),o(n,{key:0},{default:l((()=>[m(s,{name:e.meta.icon},null,8,["name"])])),_:2},1024)):h("",!0),(null==(u=e.meta)?void 0:u.title)?(i(),c("span",F,k(e.meta.title),1)):h("",!0)],8,B)],2)):h("",!0)],64)})),128))],544)]),m(g)])])):h("",!0)])),_:1})}}}),[["__scopeId","data-v-620cc64e"]]);export{I as default};
