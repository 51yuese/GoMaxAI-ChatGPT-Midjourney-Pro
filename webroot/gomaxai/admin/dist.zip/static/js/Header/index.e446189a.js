
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{d as e,W as a,a7 as s,r as n,e as t,o as i,j as o,h as l,i as r,f as c,m as d,g as m,a0 as u,F as v,J as f,n as p,k as h,t as k,ab as j,a4 as y,a1 as x}from"../main-6fd6ef79.js";import _ from"../Logo/index.a928be77.js";import g from"../Tools/index.bdecde3a.js";import{u as M}from"../useMenu/useMenu.9c4246ac.js";import"../index/index.7f16c880.js";import"../access/access.e0439180.js";const C={key:0},B={class:"header-container"},T={class:"main"},W=["onClick"],b={key:1},w=e({name:"Header"}),z=x(e({...w,setup(e){const x=a(),w=s(),{switchTo:z}=M(),F=n();function H(e){F.value.scrollBy({left:(e.deltaY||e.detail)>0?50:-50})}return(e,a)=>{const s=y,n=t("el-icon");return i(),o(j,{name:"header"},{default:l((()=>["pc"===r(x).mode&&"head"===r(x).settings.menu.menuMode?(i(),c("header",C,[d("div",B,[d("div",T,[m(_),d("div",{ref_key:"navRef",ref:F,class:"nav",onWheel:u(H,["prevent"])},[(i(!0),c(v,null,f(r(w).allMenus,((e,a)=>{var t,u;return i(),c(v,{key:a},[e.children&&0!==e.children.length?(i(),c("div",{key:0,class:p(["item-container",{active:a===r(w).actived}])},[d("div",{class:"item",onClick:e=>r(z)(a)},[(null==(t=e.meta)?void 0:t.icon)?(i(),o(n,{key:0},{default:l((()=>[m(s,{name:e.meta.icon},null,8,["name"])])),_:2},1024)):h("",!0),(null==(u=e.meta)?void 0:u.title)?(i(),c("span",b,k(e.meta.title),1)):h("",!0)],8,W)],2)):h("",!0)],64)})),128))],544)]),m(g)])])):h("",!0)])),_:1})}}}),[["__scopeId","data-v-620cc64e"]]);export{z as default};
