
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{d as e,a,A as s,r as n,l as t,b as i,J as l,i as o,g as r,e as c,f as d,h as m,p as u,Y as v,X as f,K as p,T as h,H as k,t as y,x as j,_ as x}from"../main-46c178e9.js";import _ from"../Logo/index.87067734.js";import g from"../Tools/index.5b1fa798.js";import{u as M}from"../useMenu/useMenu.9b10e413.js";import"../index/index.b6e5f6df.js";import"../access/access.8e3eb471.js";const T={key:0},C={class:"header-container"},H={class:"main"},Y=["onClick"],b={key:1},w=e({name:"Header"}),A=x(e({...w,setup(e){const x=a(),w=s(),{switchTo:A}=M(),B=n();function I(e){B.value.scrollBy({left:(e.deltaY||e.detail)>0?50:-50})}return(e,a)=>{const s=j,n=t("el-icon");return i(),l(h,{name:"header"},{default:o((()=>["pc"===r(x).mode&&"head"===r(x).settings.menu.menuMode?(i(),c("header",T,[d("div",C,[d("div",H,[m(_),d("div",{ref_key:"navRef",ref:B,class:"nav",onWheel:u(I,["prevent"])},[(i(!0),c(v,null,f(r(w).allMenus,((e,a)=>{var t,u;return i(),c(v,{key:a},[e.children&&0!==e.children.length?(i(),c("div",{key:0,class:k(["item-container",{active:a===r(w).actived}])},[d("div",{class:"item",onClick:e=>r(A)(a)},[(null==(t=e.meta)?void 0:t.icon)?(i(),l(n,{key:0},{default:o((()=>[m(s,{name:e.meta.icon},null,8,["name"])])),_:2},1024)):p("",!0),(null==(u=e.meta)?void 0:u.title)?(i(),c("span",b,y(e.meta.title),1)):p("",!0)],8,Y)],2)):p("",!0)],64)})),128))],544)]),m(g)])])):p("",!0)])),_:1})}}}),[["__scopeId","data-v-620cc64e"]]);export{A as default};
