
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{d as e,a,B as s,r as n,j as t,o as i,J as l,g as o,e as r,c as d,b as c,f as m,n as u,W as v,X as f,K as p,T as h,H as k,t as y,y as _,_ as j}from"../main-2d3d97e8.js";import x from"../Logo/index.4cc2b86c.js";import g from"../Tools/index.e9dc53ee.js";import{u as M}from"../useMenu/useMenu.9bda012d.js";import"../index/index.9ee2baf8.js";const T={key:0},B={class:"header-container"},C={class:"main"},H=["onClick"],W={key:1},b=e({name:"Header"}),w=j(e({...b,setup(e){const j=a(),b=s(),{switchTo:w}=M(),I=n();function J(e){I.value.scrollBy({left:(e.deltaY||e.detail)>0?50:-50})}return(e,a)=>{const s=_,n=t("el-icon");return i(),l(h,{name:"header"},{default:o((()=>["pc"===r(j).mode&&"head"===r(j).settings.menu.menuMode?(i(),d("header",T,[c("div",B,[c("div",C,[m(x),c("div",{ref_key:"navRef",ref:I,class:"nav",onWheel:u(J,["prevent"])},[(i(!0),d(v,null,f(r(b).allMenus,((e,a)=>{var t,u;return i(),d(v,{key:a},[e.children&&0!==e.children.length?(i(),d("div",{key:0,class:k(["item-container",{active:a===r(b).actived}])},[c("div",{class:"item",onClick:e=>r(w)(a)},[(null==(t=e.meta)?void 0:t.icon)?(i(),l(n,{key:0},{default:o((()=>[m(s,{name:e.meta.icon},null,8,["name"])])),_:2},1024)):p("",!0),(null==(u=e.meta)?void 0:u.title)?(i(),d("span",W,y(e.meta.title),1)):p("",!0)],8,H)],2)):p("",!0)],64)})),128))],544)]),m(g)])])):p("",!0)])),_:1})}}}),[["__scopeId","data-v-620cc64e"]]);export{w as default};
