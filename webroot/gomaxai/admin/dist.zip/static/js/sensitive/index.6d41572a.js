
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import e from"./violation.a95447e8.js";import t from"./baiduSensitive.1d2ebd53.js";import i from"./customSensitive.d71f392d.js";import a from"./autpReply.4ccbaa84.js";import{d as s,r as l,o,f as d,m,n as r,g as p,k as v,a0 as n}from"../main-527fe521.js";import"../marked.esm/marked.esm.3c8fbedb.js";import"../badWords/badWords.a80067c8.js";import"../utcformatTime/utcformatTime.f6db2c52.js";import"../index/index.b1051121.js";const u={style:{display:"flex","align-items":"center","margin-bottom":"16px"}},c={key:0},f={key:1},_={key:2},y={key:3},k=n(s({__name:"index",setup(s){const n=l(0);function k(e){n.value=e}return(s,l)=>(o(),d("div",null,[m("div",u,[m("div",{class:r(0==n.value?"type_title":"def_type_title"),onClick:l[0]||(l[0]=e=>k(0))},"违规检测记录",2),m("div",{class:r(1==n.value?"type_title":"def_type_title"),onClick:l[1]||(l[1]=e=>k(1))},"百度云敏感词",2),m("div",{class:r(2==n.value?"type_title":"def_type_title"),onClick:l[2]||(l[2]=e=>k(2))},"自定义敏感词",2),m("div",{class:r(3==n.value?"type_title":"def_type_title"),onClick:l[3]||(l[3]=e=>k(3))},"自定义回复词",2)]),m("div",null,[0==n.value?(o(),d("div",c,[p(e)])):v("",!0),1==n.value?(o(),d("div",f,[p(t)])):v("",!0),2==n.value?(o(),d("div",_,[p(i)])):v("",!0),3==n.value?(o(),d("div",y,[p(a)])):v("",!0)])]))}}),[["__scopeId","data-v-7efbbca1"]]);export{k as default};
