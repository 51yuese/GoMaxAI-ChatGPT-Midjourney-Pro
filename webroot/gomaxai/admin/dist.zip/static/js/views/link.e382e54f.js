
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{_ as a}from"../index/index.684d80e0.js";import{d as n,S as e,e as s,o as i,f as t,g as l,h as o,j as d,m,t as r,i as c,q as u,ab as p,a4 as k,a1 as f}from"../main-6fd6ef79.js";const _={class:"link-view"},v={class:"container"},b={class:"link"},w=n({name:"LinkView"}),j=f(n({...w,setup(n){const f=e();function w(){window.open(f.meta.link,"_blank")}return(n,e)=>{const j=k,x=s("el-icon"),y=s("el-button"),g=a;return i(),t("div",_,[l(p,{name:"link",mode:"out-in",appear:""},{default:o((()=>[(i(),d(g,{key:c(f).meta.link,title:"⚠️访问提醒"},{default:o((()=>[m("div",v,[e[1]||(e[1]=m("div",{class:"title"}," 是否访问此链接 ",-1)),m("div",b,r(c(f).meta.link),1),l(y,{type:"primary",plain:"",round:"",onClick:w},{icon:o((()=>[l(x,null,{default:o((()=>[l(j,{name:"ep:link"})])),_:1})])),default:o((()=>[e[0]||(e[0]=u(" 立即访问 "))])),_:1})])])),_:1}))])),_:1})])}}}),[["__scopeId","data-v-7b059d41"]]);export{j as default};
