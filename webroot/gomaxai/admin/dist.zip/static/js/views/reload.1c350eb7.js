
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{d as a,l as s,x as o,o as t,c as e,q as n}from"../main-2d3d97e8.js";const r=a({__name:"reload",setup(a){const n=s();return o((()=>{n.go(-1)})),(a,s)=>(t(),e("div"))}});"function"==typeof n&&n(r);export{r as default};
