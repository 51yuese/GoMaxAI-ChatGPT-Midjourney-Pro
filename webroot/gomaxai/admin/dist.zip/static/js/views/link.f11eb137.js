
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{_ as a}from"../index/index.8279f6f1.js";import{d as n,i as s,j as e,o as i,c as t,f as l,g as o,J as d,b as c,t as r,e as m,h as p,T as u,y as k,p as f,k as _,_ as v}from"../main-2d3d97e8.js";const b={class:"link-view"},w={class:"container"},y=(a=>(f("data-v-7b059d41"),a=a(),_(),a))((()=>c("div",{class:"title"}," 是否访问此链接 ",-1))),j={class:"link"},x=n({name:"LinkView"}),g=v(n({...x,setup(n){const f=s();function _(){window.open(f.meta.link,"_blank")}return(n,s)=>{const v=k,x=e("el-icon"),g=e("el-button"),h=a;return i(),t("div",b,[l(u,{name:"link",mode:"out-in",appear:""},{default:o((()=>[(i(),d(h,{key:m(f).meta.link,title:"⚠️访问提醒"},{default:o((()=>[c("div",w,[y,c("div",j,r(m(f).meta.link),1),l(g,{type:"primary",plain:"",round:"",onClick:_},{icon:o((()=>[l(x,null,{default:o((()=>[l(v,{name:"ep:link"})])),_:1})])),default:o((()=>[p(" 立即访问 ")])),_:1})])])),_:1}))])),_:1})])}}}),[["__scopeId","data-v-7b059d41"]]);export{g as default};
