
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{_ as a}from"../index/index.2a1afca6.js";import{d as n,k as e,l as s,b as i,e as t,h as l,i as o,J as d,f as r,t as c,g as m,j as u,T as k,x as p,_ as f}from"../main-46c178e9.js";const _={class:"link-view"},v={class:"container"},b={class:"link"},w=n({name:"LinkView"}),x=f(n({...w,setup(n){const f=e();function w(){window.open(f.meta.link,"_blank")}return(n,e)=>{const x=p,j=s("el-icon"),y=s("el-button"),g=a;return i(),t("div",_,[l(k,{name:"link",mode:"out-in",appear:""},{default:o((()=>[(i(),d(g,{key:m(f).meta.link,title:"⚠️访问提醒"},{default:o((()=>[r("div",v,[e[1]||(e[1]=r("div",{class:"title"}," 是否访问此链接 ",-1)),r("div",b,c(m(f).meta.link),1),l(y,{type:"primary",plain:"",round:"",onClick:w},{icon:o((()=>[l(j,null,{default:o((()=>[l(x,{name:"ep:link"})])),_:1})])),default:o((()=>[e[0]||(e[0]=u(" 立即访问 "))])),_:1})])])),_:1}))])),_:1})])}}}),[["__scopeId","data-v-7b059d41"]]);export{x as default};
