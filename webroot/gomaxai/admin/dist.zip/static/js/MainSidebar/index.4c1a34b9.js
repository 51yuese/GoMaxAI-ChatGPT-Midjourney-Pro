
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{d as a,V as e,a6 as s,e as n,o as i,j as t,h as l,i as o,f as d,g as m,m as u,F as r,J as c,n as v,k as f,t as g,aa as p,a3 as h,a0 as k}from"../main-527fe521.js";import M from"../Logo/index.1653210c.js";import{u as b}from"../useMenu/useMenu.f6a36739.js";const j={key:0,class:"main-sidebar-container"},_={class:"nav"},y=["title","onClick"],w=a({name:"MainSidebar"}),x=k(a({...w,setup(a){const k=e(),w=s(),{switchTo:x}=b();return(a,e)=>{const s=h,b=n("el-icon");return i(),t(p,{name:"main-sidebar"},{default:l((()=>["side"===o(k).settings.menu.menuMode||"mobile"===o(k).mode&&"single"!==o(k).settings.menu.menuMode?(i(),d("div",j,[m(M,{"show-title":!1,class:"sidebar-logo"}),u("div",_,[(i(!0),d(r,null,c(o(w).allMenus,((a,e)=>{var n,c,p;return i(),d(r,null,[a.children&&0!==a.children.length?(i(),d("div",{key:e,class:v(["item",{active:e===o(w).actived}]),title:(null==(n=a.meta)?void 0:n.title)??"[ 无标题 ]",onClick:a=>o(x)(e)},[(null==(c=a.meta)?void 0:c.icon)?(i(),t(b,{key:0},{default:l((()=>[m(s,{name:a.meta.icon},null,8,["name"])])),_:2},1024)):f("",!0),u("span",null,g((null==(p=a.meta)?void 0:p.title)??"[ 无标题 ]"),1)],10,y)):f("",!0)],64)})),256))])])):f("",!0)])),_:1})}}}),[["__scopeId","data-v-27edc889"]]);export{x as default};
