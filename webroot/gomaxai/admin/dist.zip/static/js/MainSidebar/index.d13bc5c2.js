
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{d as e,a,B as s,j as n,o as i,J as t,g as l,e as o,c as d,f as m,b as u,W as c,X as r,K as v,T as f,H as g,t as p,y as b,_ as M}from"../main-2d3d97e8.js";import _ from"../Logo/index.4cc2b86c.js";import{u as h}from"../useMenu/useMenu.9bda012d.js";const k={key:0,class:"main-sidebar-container"},j={class:"nav"},y=["title","onClick"],w=e({name:"MainSidebar"}),x=M(e({...w,setup(e){const M=a(),w=s(),{switchTo:x}=h();return(e,a)=>{const s=b,h=n("el-icon");return i(),t(f,{name:"main-sidebar"},{default:l((()=>["side"===o(M).settings.menu.menuMode||"mobile"===o(M).mode&&"single"!==o(M).settings.menu.menuMode?(i(),d("div",k,[m(_,{"show-title":!1,class:"sidebar-logo"}),u("div",j,[(i(!0),d(c,null,r(o(w).allMenus,((e,a)=>{var n,r,f;return i(),d(c,null,[e.children&&0!==e.children.length?(i(),d("div",{key:a,class:g(["item",{active:a===o(w).actived}]),title:(null==(n=e.meta)?void 0:n.title)??"[ 无标题 ]",onClick:e=>o(x)(a)},[(null==(r=e.meta)?void 0:r.icon)?(i(),t(h,{key:0},{default:l((()=>[m(s,{name:e.meta.icon},null,8,["name"])])),_:2},1024)):v("",!0),u("span",null,p((null==(f=e.meta)?void 0:f.title)??"[ 无标题 ]"),1)],10,y)):v("",!0)],64)})),256))])])):v("",!0)])),_:1})}}}),[["__scopeId","data-v-27edc889"]]);export{x as default};
