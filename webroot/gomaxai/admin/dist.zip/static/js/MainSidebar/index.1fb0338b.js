
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{d as a,W as e,a7 as s,e as n,o as i,j as t,h as l,i as o,f as d,g as m,m as u,F as r,J as c,n as v,k as f,t as g,ab as p,a4 as b,a1 as h}from"../main-6fd6ef79.js";import k from"../Logo/index.a928be77.js";import{u as M}from"../useMenu/useMenu.9c4246ac.js";const j={key:0,class:"main-sidebar-container"},_={class:"nav"},y=["title","onClick"],w=a({name:"MainSidebar"}),x=h(a({...w,setup(a){const h=e(),w=s(),{switchTo:x}=M();return(a,e)=>{const s=b,M=n("el-icon");return i(),t(p,{name:"main-sidebar"},{default:l((()=>["side"===o(h).settings.menu.menuMode||"mobile"===o(h).mode&&"single"!==o(h).settings.menu.menuMode?(i(),d("div",j,[m(k,{"show-title":!1,class:"sidebar-logo"}),u("div",_,[(i(!0),d(r,null,c(o(w).allMenus,((a,e)=>{var n,c,p;return i(),d(r,null,[a.children&&0!==a.children.length?(i(),d("div",{key:e,class:v(["item",{active:e===o(w).actived}]),title:(null==(n=a.meta)?void 0:n.title)??"[ 无标题 ]",onClick:a=>o(x)(e)},[(null==(c=a.meta)?void 0:c.icon)?(i(),t(M,{key:0},{default:l((()=>[m(s,{name:a.meta.icon},null,8,["name"])])),_:2},1024)):f("",!0),u("span",null,g((null==(p=a.meta)?void 0:p.title)??"[ 无标题 ]"),1)],10,y)):f("",!0)],64)})),256))])])):f("",!0)])),_:1})}}}),[["__scopeId","data-v-27edc889"]]);export{x as default};
