
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{d as e,a,A as s,l as n,b as i,J as t,i as l,g as o,e as d,h as m,f as u,Y as r,X as c,K as v,T as f,H as g,t as p,x as b,_ as h}from"../main-46c178e9.js";import M from"../Logo/index.87067734.js";import{u as k}from"../useMenu/useMenu.9b10e413.js";const _={key:0,class:"main-sidebar-container"},j={class:"nav"},x=["title","onClick"],y=e({name:"MainSidebar"}),w=h(e({...y,setup(e){const h=a(),y=s(),{switchTo:w}=k();return(e,a)=>{const s=b,k=n("el-icon");return i(),t(f,{name:"main-sidebar"},{default:l((()=>["side"===o(h).settings.menu.menuMode||"mobile"===o(h).mode&&"single"!==o(h).settings.menu.menuMode?(i(),d("div",_,[m(M,{"show-title":!1,class:"sidebar-logo"}),u("div",j,[(i(!0),d(r,null,c(o(y).allMenus,((e,a)=>{var n,c,f;return i(),d(r,null,[e.children&&0!==e.children.length?(i(),d("div",{key:a,class:g(["item",{active:a===o(y).actived}]),title:(null==(n=e.meta)?void 0:n.title)??"[ 无标题 ]",onClick:e=>o(w)(a)},[(null==(c=e.meta)?void 0:c.icon)?(i(),t(k,{key:0},{default:l((()=>[m(s,{name:e.meta.icon},null,8,["name"])])),_:2},1024)):v("",!0),u("span",null,p((null==(f=e.meta)?void 0:f.title)??"[ 无标题 ]"),1)],10,x)):v("",!0)],64)})),256))])])):v("",!0)])),_:1})}}}),[["__scopeId","data-v-27edc889"]]);export{w as default};
