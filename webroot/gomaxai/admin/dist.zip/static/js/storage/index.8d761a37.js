
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import e from"./tencent.8d899969.js";import t from"./ali.87c4ff72.js";import i from"./chevereto.1067fe03.js";import{d as l,r as a,o as s,f as o,m as n,n as v,g as d,k as r,a1 as c}from"../main-6fd6ef79.js";const p={style:{display:"flex","align-items":"center","margin-bottom":"16px"}},m={key:0},u={key:1},_={key:2},f=c(l({__name:"index",setup(l){const c=a(0);function f(e){c.value=e}return(l,a)=>(s(),o("div",null,[n("div",null,[n("div",p,[n("div",{class:v(0==c.value?"type_title":"def_type_title"),onClick:a[0]||(a[0]=e=>f(0))},"腾讯云COS",2),n("div",{class:v(1==c.value?"type_title":"def_type_title"),onClick:a[1]||(a[1]=e=>f(1))},"阿里云OSS",2),n("div",{class:v(2==c.value?"type_title":"def_type_title"),onClick:a[2]||(a[2]=e=>f(2))},"chevereto图床",2)])]),n("div",null,[0==c.value?(s(),o("div",m,[d(e)])):r("",!0),1==c.value?(s(),o("div",u,[d(t)])):r("",!0),2==c.value?(s(),o("div",_,[d(i)])):r("",!0)])]))}}),[["__scopeId","data-v-775ec094"]]);export{f as default};
