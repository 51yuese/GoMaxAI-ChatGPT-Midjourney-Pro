
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{ad as s}from"../main-2d3d97e8.js";const e={querySalesOrder:e=>s.get("sales/salesOrder",{params:e}),salesAuditOrder:e=>s.post("sales/auditOrder",e),updateSalesUser:e=>s.post("sales/updateUserSales",e),queryRecords:e=>s.get("sales/inviteRecords",{params:e}),querySalesUserList:e=>s.get("sales/salesUserList",{params:e})};export{e as A};
